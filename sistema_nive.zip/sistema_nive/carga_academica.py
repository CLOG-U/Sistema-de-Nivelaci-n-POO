class CargaAcademica:

    def __init__(self, id_carga, total_asignaturas, total_creditos, estado=True):
        self.__id_carga = id_carga
        self.__total_asignaturas = total_asignaturas
        self.__total_creditos = total_creditos

#se usa propiedades para acceder a los atributos privados
    @property
    def id_carga(self):
        return self.__id_carga

    @property
    def total_asignaturas(self):
        return self.__total_asignaturas

    @property
    def total_creditos(self):
        return self.__total_creditos

    @total_creditos.setter
    def total_creditos(self, valor):
        if valor < 0:
            print("Los creditos no pueden ser negativos")
        else:
            self.__total_creditos = valor

#genera la carga academica mostrando el total de asignaturas y creditos
    def generar_carga(self):
        print("Carga academica: " + str(self.__total_asignaturas) + " asignaturas " + str(self.__total_creditos) + " creditos")